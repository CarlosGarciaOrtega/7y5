import { Server } from "./modules/server.js";
let servidor = new Server();